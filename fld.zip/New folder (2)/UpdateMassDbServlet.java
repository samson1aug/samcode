package zetAmp_App;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import zetAmp_App.Registration;
@WebServlet("/updatemassServ")
@MultipartConfig(maxFileSize = 16177215)
public class UpdateMassDbServlet extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{ 
	//	String date=req.getParameter("dt");
		String id=req.getParameter("id");
		String cp_name= req.getParameter("value");
		Part i=req.getPart("img");
		InputStream img=convert(i);
		String series=req.getParameter("ser");
		String nOt=req.getParameter("term");
		String compo_type= req.getParameter("compotyp");
		String pstat=req.getParameter("psta");
		String size=req.getParameter("size");
		Part d=req.getPart("ds");
		InputStream datasheet=convert(d);
		String mt_typ= req.getParameter("mttyp");
		String pckg= req.getParameter("pckg");
		String menuf= req.getParameter("manuf");
		String mpn= req.getParameter("mnp");
		 String comp_val= req.getParameter("cv"); 
		String unit=req.getParameter("u");
		String volt= req.getParameter("volt");
		 String curr_rng= req.getParameter("crt"); 
		 String watt=req.getParameter("watt");
		 String tollr= req.getParameter("tlrnce");
		String desc= req.getParameter("desc"); 
		String rohs=req.getParameter("rhs");
		String feat=req.getParameter("ftr");
		String prqty=req.getParameter("pqt");
		String pckgin= req.getParameter("pckgi");
		 String avl_qty=req.getParameter("avlqt"); 
		 String reordrlvl= req.getParameter("reordlvl"); 
		 String dpr=req.getParameter("dpr");
		 String vendor= req.getParameter("vndr"); 
		 double price=Double.parseDouble(req.getParameter("price")); 
		 String flrt=req.getParameter("failr");
		   Connection con=Registration.getConnect();
		   	PreparedStatement pstmt=null;
		   	int j=0;
		   	String qry="update zetampdb.component_tab set COMP_NAME=?,IMAGE=?,SERIES=?,NO_OF_TERMINALS=?,TYPE=?,PART_STATUS=?,SIZEorDIMENSION=?,DATASHEET=?,MOUNTING_TYPE=?,PACKAGE=?,MANUFACTURER=?,MPN=?,COMP_VALUE=?,UNIT=?,VOLTAGE_RATE=?,CURRENT_RATE=?,POWER_WATTAGE=?,TOLERENCE=?,DESCRIPTION=?,ROHSorNON_ROHS=?,FEATURES=?,PURCHASED_QTY=?,PACKAGING=?,AVLBLE_QTY=?,REORDER_LEVEL=?,D_P_REORDER_QTY=?,VENDOR_NAME=?,PRICEperUNIT=?,FAILUER_RATE=? where COMP_ID=?";
		    try {
				pstmt=con.prepareStatement(qry);
				
				//pstmt.setString(1,date);
				pstmt.setString(1,cp_name);
				pstmt.setBlob(2,img);
				pstmt.setString(3,series);
				pstmt.setString(4,nOt);
				 pstmt.setString(5,compo_type);
				pstmt.setString(6,pstat); 
				pstmt.setString(7,size); 
				 pstmt.setBlob(8,datasheet);
				 pstmt.setString(9,mt_typ);
				 pstmt.setString(10,pckg);
				 pstmt.setString(11,menuf);
				  pstmt.setString(12,mpn);
				  pstmt.setString(13,comp_val);
				   pstmt.setString(14,unit);
				   pstmt.setString(15,volt);
				   pstmt.setString(16,curr_rng); 
					    pstmt.setString(17,watt);
						 pstmt.setString(18,tollr);
						 pstmt.setString(19,desc);
						 pstmt.setString(20,rohs);
						 pstmt.setString(21,feat);
						 pstmt.setString(22,prqty);
						 pstmt.setString(23,pckgin);
						  pstmt.setString(24,avl_qty);
						  pstmt.setString(25,reordrlvl);
						  pstmt.setString(26,dpr);
						  pstmt.setString(27,vendor);
						  pstmt.setDouble(28,price);
						  pstmt.setString(29,flrt);
						  pstmt.setString(30,id);
			j=pstmt.executeUpdate();
		    } catch (SQLException e) {
				e.printStackTrace();
			}
		    PrintWriter out=resp.getWriter();
		   if(j>0){
			   out.print("<script>");
				out.print("alert('Data Updated');");
				out.print("window.location='MassProdMain.jsp'");
				out.print("</script>");
		   }
			
		   else{
			   out.print("<script>");
				out.print("alert('Data Not Updated');");
				out.print("window.location='MassProdMain.jsp'");
				out.print("</script>");
		   }
			 
	}
	public static InputStream convert(Part filePart)
	{
		InputStream inputStream = null; 
	    if (filePart != null) {
	        System.out.println(filePart.getName());
	        System.out.println(filePart.getSize());
	        System.out.println(filePart.getContentType());
	         
	        try {
				inputStream = filePart.getInputStream();
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }
	    return inputStream;
	}
}
